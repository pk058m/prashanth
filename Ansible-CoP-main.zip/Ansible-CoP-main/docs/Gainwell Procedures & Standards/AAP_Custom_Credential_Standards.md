# Ansible Automation Custom Credential Standards

## Standards to follow when creating a Custom Credential in AAP

We can define a custom credential type in a standard format using a YAML/JSON-like definition, allowing the assignment of new credential types to jobs and inventory updates. 


For example, we could create a custom credential type that injects a DB username/password, an internal API username/password or an API token for a third-party web service into an environment variable, which your playbook or custom inventory script could consume.

**Note**: Custom credentials support the following ways of injecting their authentication information:

- Environment variables
- Ansible extra variables
- File-based templating (i.e., generating .ini or .conf files that contain credential values)

[Ansible Documentation on Credential Types](https://docs.ansible.com/automation-controller/latest/html/userguide/credential_types.html)

| Name | Description of the field | Production Values | Buildathon Values | Required? |
|------|-------------|---------|------------------|-----------|
| Name | The name of the Custom Credential Type. | \<Custom Name> | \<Custom Name> | <center>Y</center> |
| Description | The description of the custom Credential Type. | \<Custom Description> | \<Custom Description> | <center>N</center> |
| Input configuration | This sectoin is used to define the input configuration of a credential. <br> <br>For example:<br> - Please refer the below [examples](AAP_Custom_Credential_Standards.md#input-configuration-for-simple-usernamepassword) for JSON & YAML  references for a Simple UserName Password Combination | \<Valid Input Configuration> | \<Valid Input Configuration> | <center>Y</center> |
| Injector configuration | This sectoin is used to define the injector configuration of a credential. <br> <br>For example:<br> - Please refer the below [examples](AAP_Custom_Credential_Standards.md#input-configuration-for-complex-usernamepassword) for JSON & YAML references for a Simple UserName Password Injector configuration | \<Valid Injector Configuration> | \<Valid Injector Configuration> | <center>Y</center> |

# Simple Credentials
#### Input Configuration for Simple Username/Password 
<br> - JSON Example:
```json
{ 
 "fields": [
    {
      "id": "test_username",
      "type": "string",
      "label": "Test Service Account Username"
    },
    {
      "id": "test_password",
      "type": "string",
      "label": "Test Service Account Password",
      "secret": true
    }
  ],
  "required": [
    "test_username",
    "test_password"
  ]
}
```
<br> - YAML Example:
```yaml
fields:
  - id: test_username
    type: string
    label: Test Service Account Username
  - id: test_password
    type: string
    label: Test Service Account Password
    secret: true
required:
  - test_username
  - test_password
```
<br> 

#### Injector Configuration for Simple Username/Password
<br> - JSON Example:
```json
{
  "extra_vars": {
    "test_password": "{{ test_password }}",
    "test_username": "{{ test_username }}"
  }
}
```
<br> - YAML Example:
```yaml
extra_vars:
  test_password: '{{ test_password }}'
  test_username: '{{ test_username }}'
```
<br> 

Screenshot of a Project Credential:

![Simple Custom Credential Type](images/create_aap_simple_credential.png)

# Complex Credentials
#### Input Configuration for Complex Username/Password 
<br> - JSON Example:
```json
{ 
 "fields": [
    {
      "id": "test1_username",
      "type": "string",
      "label": "Test1 Service Account Username"
    },
    {
      "id": "test1_password",
      "type": "string",
      "label": "Test1 Service Account Password",
      "secret": true
    },
	{
      "id": "test2_username",
      "type": "string",
      "label": "Test2 Service Account Username"
    },
    {
      "id": "test2_password",
      "type": "string",
      "label": "Test2 Service Account Password",
      "secret": true
    },
	{
      "id": "test3_username",
      "type": "string",
      "label": "Test3 Service Account Username"
    },
    {
      "id": "test3_password",
      "type": "string",
      "label": "Test3 Service Account Password",
      "secret": true
    },
	{
      "id": "test...n_username",
      "type": "string",
      "label": "Test...n Service Account Username"
    },
    {
      "id": "test...n_password",
      "type": "string",
      "label": "Test...n Service Account Password",
      "secret": true
    }
  ],
  "required": [
    "test1_username",
    "test1_password",
	"test2_username",
    "test2_password",
	"test3_username",
    "test3_password",
	"test...n_username",
    "test...n_password"
  ]
}
```
<br> - YAML Example:
```yaml
fields:
  - id: test1_username
    type: string
    label: Test1 Service Account Username
  - id: test1_password
    type: string
    label: Test1 Service Account Password
    secret: true
  - id: test2_username
    type: string
    label: Test2 Service Account Username
  - id: test2_password
    type: string
    label: Test2 Service Account Password
    secret: true
  - id: test3_username
    type: string
    label: Test3 Service Account Username
  - id: test3_password
    type: string
    label: Test3 Service Account Password
    secret: true
  - id: test...n_username
    type: string
    label: Test...n Service Account Username
  - id: test...n_password
    type: string
    label: Test...n Service Account Password
    secret: true
required:
  - test1_username
  - test1_password
  - test2_username
  - test2_password
  - test3_username
  - test3_password
  - test...n_username
  - test...n_password
```
<br> 

#### Injector Configuration for Complex Username/Password
<br> - JSON Example:
```json
{
  "extra_vars": {
    "test1_password": "{{ test1_password }}",
    "test1_username": "{{ test1_username }}",
    "test2_password": "{{ test2_password }}",
    "test2_username": "{{ test2_username }}",
    "test3_password": "{{ test3_password }}",
    "test3_username": "{{ test3_username }}",
    "test...n_password": "{{ test...n_password }}",
    "test...n_username": "{{ test...n_username }}"
  }
}
```
<br> - YAML Example:
```yaml
extra_vars:
  test1_password: '{{ test1_password }}'
  test1_username: '{{ test1_username }}'
  test2_password: '{{ test2_password }}'
  test2_username: '{{ test2_username }}'
  test3_password: '{{ test3_password }}'
  test3_username: '{{ test3_username }}'
  test...n_password: '{{ test...n_password }}'
  test...n_username: '{{ test...n_username }}'
```
<br> 

Screenshot of a Project Credential:

![Simple Custom Credential Type](images/create_aap_complex_credential.png)