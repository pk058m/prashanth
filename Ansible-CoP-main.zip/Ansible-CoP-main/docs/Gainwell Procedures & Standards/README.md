# Gainwell's Digital Factory

## [Automation]

The primary tool for CD automation in Gainwell's Digital Factory is Ansible.  Ansible automation is defined in playbooks. Red Hat's Ansible Automation Platform is the application that is used to deploy the playbooks to run the defined tasks to configure the servers, applications and services.

Gainwell's AAP instance: [Ansible Automation Platform](https://ansible.stage.slhcare.com/)

```
If you don't have access to AAP, please contact Delivery Enablement Team.
```

The standards for automation are defined in this repository.

When you login to Ansible Automation Platform you will need to create a Project, and a Job Template to be able to run your automation.

For procedures and standards, please follow the procedures in the following documents:

### [Ansible Automation Platform]

Follow these links to the documentation that lays out the steps, procedures and standards to create automation in the Gainwell AAP instance.

1. [AAP Project](AAP_Project_Standards.md)
2. [AAP Job Template Procedure](AAP_Job_Template_Standards.md)
3. [AAP Credential Types](AAP_Credential_Types.md)
4. [AAP Credentials](AAP_Credentials.md)
5. [AAP - How to Execute Templates](How_To_Execute_Templates.md)
