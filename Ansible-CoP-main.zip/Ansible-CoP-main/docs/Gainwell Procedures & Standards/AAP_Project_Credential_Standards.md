# Ansible Automation Platform Project Credential Standards

## Standards to follow when creating a Project Credential in AAP

In order to have a standard that is used across all products that are part of the Gainwell Digital Factory, the following document outlines the naming standards and values that should be used for **Project Credential** created in Ansible Automation Platform.

**Note**: Project credential creation is not required unless there is no project credential configured within the AAP.

| Name | Description of the field | Production Values | Buildathon Values | Required? |
|------|-------------|---------|------------------|-----------|
| Name | The name of the Project Credential. This name must following the [Gainwell naming standards](Naming_Standards.md).  <br>For example:<br> - "GitHub-Gainwell"<br>  - "GitHub-Application" <br> - "GitHub-Capability"  <br> *\* Any testing project credentials should be removed from AAP when testing and development is complete.*  | \<Gainwell naming standard> | \<Gainwell naming standard> + identifier details | <center>Y</center> |
| Description | The description of the Project Credential should include the name of the product or capability. | \<GitHub-Organization> | \<GitHub-Organization> <br> \<GitHub-Application> | <center>N</center> |
| Organization | This has to be discussed with Delivery Enablement Team to identify the correct Organization applicable for your product. <br>For example:<br> - "Default"<br>  - "BT-Stage" <br> - "Ohio-Stage" <br> - "WV-Stage" <br> *\* The organization name ideally depends on the State and Inventory that has been setup for the product.* | \<Not Applicable> | \<Not Applicable> | <center>N</center> |
| Credential Type | Choose from the drop down list - i.e., **Source Control**. By default since this is a source control credential we need not define a Credential type and select from the available list of options. | \<Source Control> | \<Source Control> | <center>Y</center> |
| User Name | This is the UserName that has access privileges for AAP to access the GitHub Repo | \<UserName> | \<UserName> | <center>Y</center> |
| Password | This is the password that has access privileges for AAP to access the GitHub Repo. <br> <br> - Note: This field is an encrypted field and it does not reveal the credentials once they are saved. Even AAP admins cannot reveal the passwords. <br> <br> If future if the password has to be changed/updated, you can visite the credentail and update it by clicking on the **Replace** button adjacent to the password field | \<Password> | \<Password> | <center>Y</center> |
| SCM Private Key | This is Not applicable as we are configurting Password <br> <br> If needed please configure the SCM private key of the GitHub Source Control URL. | \<Not Applicable> |  \<Not Applicable> | <center>N</center> |
| Private Key Passphrase  | This is Not applicable as we are configurting Password <br> <br> If needed please configure the SCM private key Passphrase of the GitHub Source Control URL. | \<Not Applicable> |  \<Not Applicable> | <center>N</center> |


Screenshot of a Project Credential:

![AAP Project](images/create_aap_project_credential.png)