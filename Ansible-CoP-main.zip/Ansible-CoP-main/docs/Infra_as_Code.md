# Infrastructure as Code
One key DevOps concept is the idea of **infrastructure as code.** Instead of managing your infrastructure manually, you define and build your systems by running your automation code. Red Hat Ansible Automation Platform is a key tool that can help you implement this approach.

If Ansible projects are the code used to define the infrastructure, then a version control system such as Git should be used to track and control changes to the code.

Version control also allows you to implement a lifecycle for the different stages of your infrastructure code, such as development, QA, and production. You can commit your changes to a branch and test those changes in noncritical development and QA environments. When you are confident with the changes, you can merge them to the main production code and apply the changes to your production infrastructure.
# Introducing Git
Git is a distributed version control system (DVCS) that allows you to manage changes to files in a project collaboratively. Using Git provides many benefits:

 * You can review and restore earlier versions of files.

* You can compare two versions of the same file to identify changes.

* You can record a log of who made what changes, and when those changes were made.

* Multiple users can collaboratively modify files, resolve conflicting changes, and merge the changes.

Using Git, you can start by cloning an existing shared project from a remote repository. Cloning a project creates a complete copy of the original remote repository as a local repository. This local copy has the entire history of the files in Git, and not just the latest snapshot of the project files.

You make edits in a working tree, which is a checkout of a single snapshot of the project. Next, you place the modified files in a staging area, to commit the differences to the local repository. At this point, no changes have been made to the shared remote repository.

When you are ready to share the work done, you push changes to the remote repository. Alternatively, if the local repository is accessible from the network, then the owner of the remote repository can pull the changes from your local repository to the remote repository.

Likewise, when you are ready to update the local repository with the latest changes to the remote repository, you can pull the changes, which fetches them from the remote repository and merges them into the local repository.

# Working with Branches and References
Branches allow you to make changes to your project, working on new development, without altering your main line. Then, when you are satisfied with your changes, you can merge the changes in your branch to the main line of development, integrating them.

A branch is essentially a pointer to a particular commit in your commit tree. Each commit contains the changes it made and information about how to reference it and what its relationship is to other commits in the commit tree. The information in a commit includes:

* A unique ID in the form of a 40-character hexadecimal string. This ID is the SHA-1 hash of the contents of the commit.

* A list of repository files that it changed, and the exact changes to each of them.

* The ID of the parent commit that defines the status of the repository before applying the commit in question.

* Information about the author and the creator (or committer) for the commit in the commit data.

* A list of references. A reference is like a named pointer to the commit. The most common references are tags and branches.

The git commit command generates a new commit with all changes added to the stage with the git add command. You can see a Git repository as a commit graph, and branches as references to commits.

# Roles and Ansible Content Collections
You can include roles and Ansible Content Collections in your Ansible project's Git repository. In this case each collection is generally stored in subdirectories of the collections/ directory, and each role is stored in subdirectories of the roles directory. There might also be a requirements.yml file in either or both of those directories that specifies collections or roles that are used by this project, which the ansible-galaxy command can download as needed.

Including roles and collections in an Ansible project directory structure takes some thought to manage well. If your roles and collections are managed as part of the playbook, then keeping them with the playbook can make sense. However, most roles and collections are meant to be shared by multiple projects, and if each project has its own copy of each role or collection, then they could diverge from each other, losing some of the benefits of using them.

A role or collection should have its own Git repository. Some people try to include these repositories in their project repositories by using an advanced feature of Git called submodules. Because submodules can be tricky to manage successfully, this is not a recommended approach.

**A better approach is to set up requirements.yml files in your roles/ and collections/ directories and to use the ansible-galaxy command to populate this directory with the latest version of roles from automation hub, Ansible Galaxy, or their Git repositories before you run the project's playbooks.**

For more information, please refer to: https://docs.github.com/en/get-started/quickstart/set-up-git