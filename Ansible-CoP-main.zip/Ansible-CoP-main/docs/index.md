# Welcome to Ansible Community of practice

<p align="center">
  <img src="https://upload.wikimedia.org/wikipedia/commons/2/24/Ansible_logo.svg" />
</p>

## What is community of practice?

The Ansible community of practice is comprised of Gainwell employees who are passionate about automation, aspiring to learn automation using Ansible and our partners RedHat who support Ansible. Everyone in Gainwell is welcome to join this community. Together, we can learn, contribute and grow in our automation journey.

## Governance body

- Sponsor - Ken Vachon (@KenVachon)
- Moderator - Shashank Kharel (@kharels)
- Member - Nishanth Kunduru (@nieshanttreddy) - Gainwell, Bret Quist (@mvd407)- RedHat, Jeremy Hallock (@jeremyhallock) - Effectual

## Getting Started

- join github and be added to the ansible COP repo
- Read the documents and contributing guidelines
- Ask questions and get help using issues
- Submit your contributions

## Documents

- how to read the docs with links included

## Contributing guidelines

- How to contribute
- Issues templates
- Pull requests templates
