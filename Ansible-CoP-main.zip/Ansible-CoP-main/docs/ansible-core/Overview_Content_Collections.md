# Ansible Content Collections 
Ansible Content Collections are a distribution format for Ansible content. A collection provides a set of related modules, roles, and plug-ins that you can download to your control node and then use in your playbooks.

With collections, you can separate core Ansible code updates from updates to modules and plug-ins. Vendors and developers can then maintain and distribute their collections at their own pace, independently of Ansible releases. **You can develop your own collections to provide custom roles and modules to your teams.**

Collections also give you more flexibility. By using collections, you can install only the content you need instead of installing all supported modules. You can also select a specific version of a collection (possibly an earlier or a later one) or choose between a version of a collection supported by Red Hat and one provided by the community.

Upstream Ansible unbundled most modules from the core Ansible code in Ansible Base 2.10 and Ansible Core 2.11 and placed them in collections. **Red Hat Ansible Automation Platform 2.0 provides automation execution environments based on Ansible Core 2.11 that inherit this feature.**

# Organizing Ansible Content Collections in Namespaces
To make it easier to specify collections and their contents by name, collection names are organized into **namespaces.** Vendors, partners, developers, and content creators can use namespaces to assign unique names to their collections without conflicting with other developers.

The namespace is the first part of a collection name. For example, all the collections that the Ansible community maintain are in the community namespace, and have names such as community.crypto, community.postgresql, and community.rabbitmq. **Collections that Red Hat maintain and support might use the redhat namespace, and have names such as redhat.rhv, redhat.satellite, and redhat.insights.** Names of namespaces are limited to ASCII lowercase letters, numbers, and underscores, must be at least two characters long, and must not start with an underscore.

For example:

* The redhat.insights collection groups modules and roles that you can use to register a system with Red Hat Insights for Red Hat Enterprise Linux.

* The cisco.ios collection groups modules and plug-ins that manage Cisco IOS network appliances. The Cisco company supports and maintains that collection.

* The community.crypto collection provides modules that create SSL/TLS certificates.

Ansible always includes a special collection named **ansible.builtin.** This collection includes a set of common modules, such as copy, template, file, yum, command, and service.

# Using Ansible Content Collections
The automation execution environments that Red Hat provides already include some collections. You can install additional collections on your local system or create a custom automation execution environment that incorporates these collections.

Use the **ansible-navigator collections** command to list the collections available in automation execution environments.   Example output:

![collections](/docs/AAP/images/collections.jpg)

To list the modules and plug-ins for a collection, type the associated collection number. If the collection number is greater than nine, type a colon before the collection number, such as :19 for line 19, and then press Enter. 

The following output shows the modules available in the redhat.insights collection.

![collections_output](/docs/AAP/images/collection_output.jpg)

# Using Ansible Content Collections in Playbooks
To use a module or a role from a collection, refer to it with its fully qualified collection name (FQCN). For example, use redhat.insights.insights_register to refer to the insights_register module.

The play in the following playbook includes a task that calls the insights_register module.

![insights](/docs/AAP/images/insights_ex.jpg)

# Finding Ansible Content Collections

 https://github.com/ansible/ansible/blob/devel/lib/ansible/config/ansible_builtin_runtime.yml file maps old module names from Ansible 2.9 to their new FQCNs.

For more information please refer to:  https://docs.ansible.com/ansible/latest/user_guide/collections_using.html