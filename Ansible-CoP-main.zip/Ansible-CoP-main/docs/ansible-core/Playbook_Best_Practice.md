
# The Effectiveness of Ansible
As you work with more advanced features and larger, more complex projects, it becomes more difficult to manage and maintain Ansible Playbooks, or to use them effectively.

This course introduces a number of advanced features of Red Hat Ansible Automation Platform. Using Ansible effectively is not just about features or tools, but about practices and organization.

To paraphrase Ansible developer Jeff Geerling, using Ansible effectively relies on three key practices:

* Keep things simple

* Stay organized

* Test often

Keep your **playbooks as simple as possible.** Don’t put too much logic in your playbook, put it in your **roles** (or even in custom modules), and try to limit your playbooks to a list of a roles.

# Keeping Things Simple

One of the strengths of Ansible is its simplicity. Simple playbooks are easier to use, modify and understand.

* Keeping Your Playbooks Readable
Keep your playbooks well commented and easy to read. Use vertical white space and comments liberally. Always give plays and tasks meaningful names that make clear what the play or task is doing. These practices help document the playbook and make it easier to troubleshoot a failed playbook run.

* YAML is not a programming language. It is good at expressing a list of tasks or items, or a set of key-value pairs. If you are struggling to express some complex control structure or conditional in your Ansible Playbook, then consider approaching the problem differently. There are clever things you can do with templates and Jinja2 filters to process data in a variable, which might be a better approach to your problem.

Use native YAML syntax, not the "folded" syntax. For example, the following example is not a recommended format:

![yaml](/docs/AAP/images/YAML.jpg)

# Use Existing Modules
When writing a new playbook, start with a basic playbook and, if possible, a static inventory. Use debug modules as stubs as you build your design. When your playbook functions as expected, break up your playbook into smaller, logical components using imports and includes.

* Use special-purpose modules included with Ansible when you can, instead of command, shell, raw, or other similar modules. It will be a lot easier to make your playbook idempotent and simple to maintain if you use the modules designed for a specific task.

* Many modules have a default state or other variables that control what they do. For example, the yum module currently assumes that the package you name should be present in most cases. However, you should explicitly specify what state you want. Doing so makes it easier to read the playbook, and protects you against changes in the module's default behavior in later versions of Ansible.

* Adhering to a Standard Style
Consider having a standard "style" that your team follows when writing Ansible projects. For example, how many spaces do you indent? How do you want vertical white space used? How should tasks, plays, roles, and variables be named? What should get commented on and how? There are many reasonable ways to do this, but having a consistent standard can help improve maintainability and readability.

# Staying Organized

Well-organized standards can help with maintainability, troubleshooting, and auditing. Take advantage of Ansible organization features, such as roles, so that you can reuse them.

Following Conventions for Naming Variables
Variable naming can be significant because Ansible has a reasonably flat namespace. Use descriptive variables, such as apache_tls_port rather than a less explanatory variable such as p. In roles, it is a good practice to prefix role variables with the role name.

If the name of your role is myapp then prefix your variables with myapp_ so that you can easily identify them from variables in other roles and the playbook.

Variable names should clarify contents. A name such as apache_max_keepalive clearly explains the meaning of the associated value (or values). Prefix roles and group variables with the name of the role or group to which the variable belongs. apache_port_number is more error-resistant than port_number.

# Standardizing the Project Structure


Use a consistent pattern when structuring the files of your Ansible project on a file system. There are several useful patterns, but the following is a good example:

![role_dir](/docs/AAP/images/roles_yaml.jpg)

The file site.yml is the main playbook, which includes or imports playbooks that perform specific tasks: dbservers.yml, storage.yml, and webservers.yml. Each role is located in subdirectories in the roles directory, such as std_server. There are two static inventories in the inventories/prod and inventories/stage directories with separate inventory variable files so that you can select different sets of servers by changing the inventory you use.

One of the playbook structure benefits is that you can divide up your extensive playbook into smaller files to make it more readable. Those smaller subplaybooks can contain plays for a specific purpose that you can run independently.

# Using Dynamic Inventories
Use dynamic inventories whenever possible. Dynamic inventories allow central management of your hosts and groups from one primary source of truth and ensure that the inventory updates. Dynamic inventories are especially powerful in conjunction with cloud providers, containers, and virtual machine management systems. Those systems might already have inventory information in a form that Ansible can consume.

If you cannot use dynamic inventories, then other tools can help you construct groups or extra information. For example, you can use the group_by module to generate group membership based on a fact. That group membership is valid for the rest of the playbook.

# Using Roles and Ansible Content Collections for Reusable Content
Roles and collections help you keep your playbooks simple and allow you to save work by reusing standard code across projects. If you write your own roles and collections, keep them focused on a particular purpose or function, just like you do with playbooks. Make roles generic and configurable through variables so that you do not need to edit them when you use them with a different set of playbooks.

Use the ansible-galaxy command to initialize the directory hierarchy for your role or collection and provide initial template files. It will be easier to share your content through private automation hub or on the community Ansible Galaxy website if you choose to do so.

# Take advantage of Red Hat Ansible Certified Content Collections. 
These are supported with your Ansible Automation Platform subscription, and provide many useful functions and features.

You can also examine the roles provided by the community through Ansible Galaxy. Be aware that these roles have varying levels of quality, so if you use them, choose the ones that you use carefully.

# Keep your roles in the roles subdirectory of your project, and your collections in the collections subdirectory of your project. 
(Your collections might contain roles, of course, and those should stay in their collection's directory.) Use the ansible-galaxy command to get roles from automation hub or a separate Git repository automatically.
Running Playbooks Centrally
To control access to your systems and audit Ansible activity, consider using a dedicated control node from which all Ansible Playbooks are run. Ideally, you should use automation controller.

System administrators should still have their own accounts on the system, as well as credentials to connect to managed hosts and escalate privileges, if needed. When a system administrator leaves, their SSH key can be removed from managed hosts' authorized_keys file and their sudo command privileges revoked, without impacting other administrators.

# Consider using automation controller as this central host. 
Automation controller is included with your Red Hat Ansible Automation Platform subscription, and provides features that make it easier to control access to credentials, control playbook execution, simplify automation for users who are not comfortable with the Linux command line, as well as audit and track playbook runs. Later in this course, you learn about using automation controller. However, even if you do not use automation controller, using a central control node can be beneficial.

# Building Automation Execution Environments
Create a custom automation execution environment if you need to frequently use specific Ansible Content Collections, especially if the collection requires Python dependencies or system executables not included in the supported automation execution environments.

However, if you can use an existing automation execution environment to run your playbooks, you should consider doing that. Reusing automation execution environments can reduce maintenance effort and the number of execution environments that you must manage.

# Testing Often
Test your playbooks and your tasks frequently during the development process, when the tasks run, and after the playbooks are in use.

# Roles

Roles are meant to be re-used and the structure helps you to make your code re-usable. The more code you put in roles, the higher the chances you, or others, can reuse it. Also, if you follow the type-function pattern, you can very easily create new (type) playbooks by just re-shuffling the roles. This way you can create a playbook for each purpose without having to duplicate a lot of code. This, in turn, also helps with the maintainability as there is only a single place where necessary changes need to be implemented, and that is in the role.  As an example:

![role](/docs/AAP/images/roles.jpg)

# Use Tags Cautiously Either for Roles or for Complete Purposes

Limit your usage of tags to two aspects:

* Either tags called like the roles to switch on/off single roles,

* Or specific tags to reach a meaningful purpose

Don’t set tags which can’t be used on their own, or can be destructive if used on their own.

Also document tags and their purpose(s).

There is nothing worse than tags which can’t be used alone, they bear the risk to destroy something by being called standalone. An acceptable exception is the pattern to use the role name as tag name, which can be useful while developing the playbook to test, or exclude, individual roles.

Important is that your users don’t need to learn the right sequence of tags necessary to get a meaningful result, one tag should be enough.

![listofroles](/docs/AAP/images/list_of_roles.jpg)

You see that each role can be skipped/run individually, but also that the tags deploy and configure can be used to do something we’ll assume to be meaningful, without having to explain at length what they do.

# Define your inventory as structured directory instead of single file

Everybody has started with a single file inventory in ini-format (the courageous ones among us in YAML format), combining list of hosts, groups and variables. An inventory can nevertheless be also a directory containing:

* list(s) of hosts

* list(s) of groups, with sub-groups and hosts belonging to those groups

* dynamic inventory plug-ins configuration files

* dynamic inventory scripts (deprecated but still simple to use)

* structured host_vars directories

* structured group_vars directories

The recommendation is to start with such a structure and extend it step by step.

It is the only way to combine simply multiple sources into one inventory, without the trouble to call ansible with multiple -i {inventory_file} parameters, and keep the door open for extending it with dynamic elements.

It is also simpler to maintain in a Git repository with multiple maintainers as the chance to get a conflict is reduced because the information is spread among multiple files. You can drop roles' defaults/main.yml file into the structure and adapt it to your needs very quickly.

And finally it gives you a better overview of what is in your inventory without having to dig deeply into it, because already the structure (as revealed with tree or find) gives you a first idea of where to search what. This makes on-boarding of new maintainers a lot easier.

![tree](/docs/AAP/images/tree.jpg)

* 1: this is your inventory directory
* 2: a configuration file for a dynamic inventory plug-in
* 3: a dynamic inventory script, old style and deprecated but still used (and supported)
* 4: a file containing a static list of hosts and groups, the name isn’t important (often called hosts but some might confuse it with /etc/hosts and it also contains groups). See below for an example.
* 5: the group_vars directory to define group variables. Notice how each group is represented by a directory of its name containing one or more variable files.
* 6: the host_vars directory to define host variables. Notice how each host is represented by a directory of its name containing one or more variable files.
