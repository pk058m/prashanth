
# User

A User is someone who has access to the automation controller with associated permissions and credentials. Access the Users page by clicking Users from the left navigation bar. The User list may be sorted and searched by Username, First Name, or Last Name and click the headers to toggle your sorting preference.
Three types of Users can be assigned:

## Normal User

Normal Users have read and write access limited to the resources (such as inventory, projects, and job templates) for which that user has been granted the appropriate roles and privileges.

## System Auditor

 Auditors implicitly inherit the read-only capability for all objects within the environment.

## System Administrator

A System Administrator (also known as Superuser) has full system administration privileges – with full read and write privileges over the entire installation. A System Administrator is typically responsible for managing all aspects of automation controller and delegating responsibilities for day-to-day work to various Users. Assign with caution!

## Users Organization

This displays the list of organizations of which that user is a member. This list may be searched by Organization Name or Description. Organization membership cannot be modified from this display panel.

# Teams

A Team is a subdivision of an organization with associated users, projects, credentials, and permissions. Teams provide a means to implement role-based access control schemes and delegate responsibilities across organizations. For instance, permissions may be granted to a whole Team rather than each user on the Team.

Teams are groups of users. Teams make managing roles on automation controller objects, such as inventories, projects, and job templates, more efficient than managing roles for each user separately. Automation controller administrators can assign roles to teams. All team members inherit the roles assigned to that team.  This means that you do not have to assign the same roles to multiple, individual users.

In automation controller, users exist as objects at an automation controller-wide level. Therefore, a user can have roles in multiple organizations. By contrast, a team belongs to exactly one organization. However, an admin user can assign the team roles on resources that belong to other organizations.


You can assign organization roles to teams.

You can create as many Teams of users as make sense for your Organization. Each Team can be assigned permissions, just as with Users. Teams can also scalably assign ownership for Credentials, preventing multiple interface click-throughs to assign the same Credentials to the same user.

# Team Roles

You can assign roles to users for a particular team. These roles control whether the user can manage the team, or can only view team membership.

You can assign multiple team roles to users. These roles are described in the following sections.

* The Member Role
Users with the team Member role inherits roles on automation controller resources granted to the team. It also grants users the ability to view the team's users and associated team roles.

* The Admin Role
The Admin team role grants users full control of the team. Users with this team role can manage the team's users and their associated team roles. Users with Admin team roles can also manage the team's roles on resources for which the team has been assigned the Admin role. Users with Admin team roles can only manage the team's roles on a resource when the resource also grants the Admin team role on itself. Just because a team Admin can manage team membership, it does not imply that the team Admin has any rights to manage roles on objects to which the team has access. For example, for a user to grant a team the Use role for a project, the user must have the Admin role for both the team and the project.

* The Read Role
The Read team role gives users the ability to view the team's users and their associated team roles. A user assigned a Read team role does not inherit roles that the team has been granted on automation controller resources. Access the Teams page by clicking Teams from the left navigation bar. The team list may be sorted and searched by Name or Organization.
Until a Team has been created and the user has been assigned to that team, the assigned Teams Details for the User appears blank.

For more information about teams, refer to the Automation Controller User Guide at <https://docs.ansible.com/automation-controller/latest/html/userguide/teams.html>

# Organization Roles

As previously stated, many roles provide access to an organization and multiple roles can be assigned to users and teams.  The following organization roles can be assigned to both user and teams.

* Execute-
When assigned the Execute role on an organization, a user gains permission to execute job templates and workflow job templates in the organization.

* Project Admin-
A user with the Project Admin role can create, read, update and delete any project in the organization. In conjunction with the Inventory Admin permission, this allows users to create job templates. Inventory Admin::A user with the Inventory Admin role can create, read, update and delete any inventory in the organization. In conjunction with the Job Template Admin and Project Admin roles, this allows the user full control over job templates within the organization.

* Credential Admin-
A user with the Credential Admin role can manage all credentials of the organization.

* Workflow Admin-
A user with the Workflow Admin role can manage all workflows of the organization.

* Notification Admin-
A user with the Notification Admin role can manage all notifications of the organization.

* Job Template Admin-
A user with the Job Template Admin role can make changes to nonsensitive fields within job templates. To make changes to fields that impact job runs, the user also needs the Admin role on the job template, the Use role on the related project, and the Use role in the related inventory.

* Execution Environment Admin-
A user with the Execution Environment Admin role can manage all execution environments of the organization.

* Auditor-
When assigned the Auditor role on an organization, a user gains read-only access to the organization.

* Read-
When assigned the Read role on an organization, a user gains read permission to the organization only. The organization Read role only provides a user with the ability to view the list of users who are members of the organization and their assigned organization roles. Unlike the organization Admin and Auditor roles, the Read role does not inherit roles on any of the resources that the organization contains, such as teams, credentials, projects, inventories, job templates, workflow job templates, and notifications. The organization object cannot be assigned roles on automation controller resources. Therefore, a user that has the Member role on an organization only has access to the organization object and inherits no other permissions as a result of this role. Consequently, a user that has the Member role on an organization is the equivalent of a user that has the Read role on an organization.

* Approve
A user with the Approve role can approve or deny a workflow approval node.

For more information about organizations, refer to the Automation Controller User Guide at <https://docs.ansible.com/automation-controller/latest/html/userguide/organizations.html>

# Inventory Roles

You can assign appropriate RBAC roles to users and teams for an inventory, in order to grant users the ability to read, use, or manage it.  The following is a list of available roles for an inventory:

![inventory_roles](/AAP/images/inventory_roles.jpg)

When you create an inventory, it is only accessible by users who have the Admin, Inventory Admin, or Auditor roles for the organization to which the inventory belongs. You have to configure access to all other users.
First, you need to create the inventory and save it, and after that, you can assign users and teams appropriate roles as discussed previously.

Please refer to how to build your inventory: <https://docs.ansible.com/ansible/latest/user_guide/intro_inventory.html#intro-inventory>

# Users - Permissions

The set of Permissions assigned to this user (role-based access controls) that provide the ability to read, modify, and administer projects, inventories, job templates, and other automation controller elements are Privileges.

### Add Permissions

To add permissions to a particular user:
Click the Add button, which opens the Add Permissions Wizard. Click to select the object for which the user will have access and click Next. Click to select the resource to assign team roles and click Next. Click the checkbox beside the role to assign that role to your chosen type of resource. Different resources have different options available.

Click Save when done, and the Add Permissions Wizard closes to display the updated profile for the user with the roles assigned for each selected resource.

To remove Permissions for a particular resource, click the disassociate (x) button next to its resource. This launches a confirmation dialog, asking you to confirm the disassociation.

For more information please refer to: <https://docs.ansible.com/automation-controller/latest/html/userguide/users.html>
