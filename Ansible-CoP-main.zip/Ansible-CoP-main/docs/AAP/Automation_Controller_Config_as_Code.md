It is recommended, per the [Ansible Automation Platform Reference Architecture](https://access.redhat.com/documentation/en-us/reference_architectures/2021/html/deploying_ansible_automation_platform_2.1/overview), that any controller configuration be managed as Ansible code in a Git repository. This improves resiliency and assists in moving configuration between multiple Controller environments.


An example can be found at: <https://github.com/zjpeterson/ansible-controller-as-code>
