# Ansible Automation Plaform (AAP) Suggested Training

## Ansible Basics - Automation Technical Overview

This is a free series of on-demand, online videos, ([Course: DO007](https://www.redhat.com/en/services/training/do007-ansible-essentials-simplicity-automation-technical-overview?extIdCarryOver=true&sc_cid=701f2000001OH6uAAG)) that introduce you to the Red Hat Ansible Automation Platform. Learn configuration management, provisioning, deploying, and managing compute infrastructure across cloud, virtual, and physical environments with Ansible.  Content includes:


* Intro to Ansible Automation Platform
* How it works
* Understanding modules, tasks, playbooks
* How to execute Ansible commands
* Using variables and templates
* Automation controller - where it fits in
* Automation controller basics
* Automation controller features - RBAC, workflows.

Audience for this course include:
IT leaders, administrators, engineers, architects, and anyone else seeking a high-level understanding of Ansible and to learn to build Ansible from the ground up.

## Try Out Interactive Learning Scenarios For The Red Hat Ansible Automation Platform

These [interactive learning](https://www.ansible.com/products/ansible-training) scenarios provide you with a pre-configured Ansible Automation Platform environment to experiment, learn and see how the platform can help you solve real-world problems.  The environment runs entirely in your browser, enabling you to learn more about the technology at your pace and time.

![training](/AAP/images/Training.png)

## Ansible Automation Platform 2 E-Book

In this [interactive guide](https://www.redhat.com/en/resources/ansible-automation-platform-2-ebook), learn about the features of Red Hat® Ansible® Automation Platform 2, based on 4 different automation roles: architect, administrator, creator, and operator. This e-book contains frequently asked questions and information about automation execution environments, automation controller, Ansible content tools, Ansible Content Collections, automation services catalog, automation hub, and Red Hat Insights for Red Hat Ansible Automation Platform. Get the e-book to learn more.
