# Automation Controller

Red Hat Ansible Automation Platform 2 includes a component called automation controller, which was called Red Hat Ansible Tower in earlier versions of Ansible Automation Platform. Automation controller provides a centralized hub that you can use to run your Ansible automation code.  Enterprise IT organizations need a way to define and embed automation workflows for other tools and processes. They also need reliable and scalable automation execution, and a centralized system that allows auditing.

With the Automation controller, companies automate with confidence and reduce automation drift and variance across the enterprise by standardizing how automation deploys in one centralized location.

Automation controller provides a framework for running and managing Ansible efficiently on an enterprise scale. It simplifies the administration involved with coordinating the execution of automation code. It also maintains organization security by introducing features such as a centralized web UI for playbook management, role-based access control (RBAC), and centralized logging and auditing. Its REST API ensures that the automation controller integrates easily with an enterprise's existing workflows and tool sets. The automation controller API and notification features make it particularly easy to associate Ansible Playbooks with other tools to enable continuous integration and deployment. It provides mechanisms to enable centralized use and control of machine credentials and other secrets without exposing them to end users of automation controller.

Describing the Architecture of Automation Controller
The introduction of automation execution environments in Red Hat Ansible Automation Platform 2 has allowed automation controller to decouple its control plane from its execution environment.

In Red Hat Ansible Tower 3.8 and earlier, the execution environment was tightly coupled to the system that ran Ansible Tower. This made it hard to manage the dependencies of various modules needed to run Ansible Playbooks. Changes to the execution environment had to be made directly on the Ansible Tower system, and if two playbooks required different environments, Python virtual environments ("venv") had to be set up and updated manually to manage them. Some enterprises ended up with tens or hundreds of venvs.

Automation controller improved this architecture significantly. Instead of using the system executables and Python installation or virtual environment, it uses an automation execution environment. These environments are containers that you can pull from a central container registry, automatically install on automation controller, and manage through the web UI. Developers can easily publish updates to the container registry. Developers can create these exact automation execution environments, then use ansible-navigator to ensure that they work with their automation code. This helps ensure that automation code runs consistently on both the developer's system and in automation controller.


# Automation Controller Features

The following are some of the many features offered by automation controller for controlling, securing, and managing Ansible in an enterprise environment:

* Visual Dashboard
The automation controller web UI displays a Dashboard that provides a summary view of an enterprise's entire Ansible environment. Administrators can use the automation controller Dashboard to see the current status of hosts and inventories, and the results of recent job executions. Automation controller's upgraded user UI provides better security and performance and improves observability with new filtering capabilities and distinct views.

* Role-based Access Control (RBAC)
Automation controller uses a Role-based Access Control (RBAC) system, which maintains security when streamlining user access management. This system simplifies assigning user access to automation controller objects, such as organizations, projects, and inventories.

* Graphical Inventory Management
You can use the automation controller web UI to create inventory groups and add inventory hosts. You can keep some projects private when allowing users to edit inventories. Alternatively, you can update inventories from an external inventory source such as public cloud providers, local virtualization environments, an organization's custom configuration management database (CMDB), or content in a Git repository.

* Task Manager and Job Scheduling
Use automation controller to schedule playbook execution and updates from external data sources either on a one-time or recurring basis. This allows routine tasks to run unattended, and is especially useful for tasks such as backup routines, which are ideally executed during operational off-hours.

* Real-time and Historical Job Status Reporting
When you initiate a playbook run in automation controller, the web UI displays the playbook's output and execution results in real time. The results of previously executed jobs and scheduled job runs are also available from automation controller for auditing or review.

* User-triggered Automation
Ansible simplifies IT automation, and automation controller takes it a step further by enabling user self-service. Administrators can use the automation controller web UI, coupled with the flexibility of its RBAC system, to reduce complex tasks to simple routines that are easy to use.

* Credential Management
Automation controller centrally manages authentication credentials. This means that you can run Ansible plays on managed hosts, synchronize information from dynamic inventory sources, and import Ansible project content from version control systems. Automation controller encrypts the passwords or keys provided so that automation controller users cannot retrieve them. Users can be granted the ability to use or replace these credentials without exposing the secrets in the current credentials to the user.

* Centralized Logging and Auditing
Automation controller logs all playbook and remote command execution. This provides the ability to audit when each job was executed and by whom. In addition, automation controller offers the ability to integrate its log data into third-party logging aggregation solutions, such as Splunk and Sumologic.

* Integrated Notifications
Automation controller notifies you when job executions succeed or fail. Automation controller can deliver notifications using many applications, including email, Grafana, IRC, Mattermost, Slack, Rocket.Chat, Twilio, and Webhooks.

* Multiplaybook Workflows
Complex operations often involve the serial execution of multiple playbooks. Users can use automation controller multiplaybook workflows to chain together numerous playbooks, to facilitate the implementation of complex routines involving provisioning, configuration, deployment, and orchestration. An intuitive workflow editor also helps to simplify the modeling of multiplaybook workflows.

* Browsable RESTful API
The automation controller's RESTful API exposes every automation controller feature available through the web UI. The browsable format of the API makes it self-documenting and makes it easier for you to look up information on how to use it.

For more information please refer to: <https://docs.ansible.com/automation-controller/latest/html/userguide/index.html>
