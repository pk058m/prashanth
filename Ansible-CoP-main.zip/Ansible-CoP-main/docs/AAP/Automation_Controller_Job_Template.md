

# Job Template

A job template is a definition and set of parameters for running an Ansible job. Job templates are useful to execute the same job many times. Job templates also encourage the reuse of Ansible playbook content and collaboration between teams.

The **Templates menu** opens a list of the job templates that are currently available. The default view is collapsed (Compact), showing the template name, template type, and the timestamp of last job that ran using that template. You can click Expanded (arrow next to each entry) to expand to view more information. This list is sorted alphabetically by name, but you can sort by other criteria, or search by various fields and attributes of a template.

## To Create a New Job Template

Click the Add button then select Job Template from the menu list.
Enter the appropriate details into the following fields:

* Name: Enter a name for the job.
* Description: Enter an arbitrary description as appropriate (optional).
* Job Type: Choose a job type:
* Run: Execute the playbook when launched, running Ansible tasks on the selected hosts.
* Check: Perform a “dry run” of the playbook and report changes that would be made without actually making them. Tasks that do not support check mode will be skipped and will not report potential changes.
Prompt on Launch: If selected, even if a default value is supplied, you will be prompted upon launch to choose a job type of run or check.
* Inventory: Choose the inventory to be used with this job template from the inventories available to the currently logged in user.
* Prompt on Launch: If selected, even if a default value is supplied, you will be prompted upon launch to choose an inventory to run this job template against.
* Project: Choose the project to be used with this job template from the projects available to the currently logged in user.
* SCM Branch: This field is only present if you chose a project that allows branch override. Specify the overriding branch to use in your job run. If left blank, the specified SCM branch (or commit hash or tag) from the project is used. For more detail, see job branch overriding.
* Prompt on Launch: If selected, even if a default value is supplied, you will be prompted upon launch to choose an SCM branch.
* Playbook: Choose the playbook to be launched with this job template from the available playbooks. This field automatically populates with the names of the playbooks found in the project base path for the selected project. Alternatively, you can enter the name of the playbook if it is not listed, such as the name of a file (like foo.yml) you want to use to run with that playbook. If you enter a filename that is not valid, the template will display an error, or cause the job to fail.
*Credentials: Click the  button to open a separate window. Choose the credential from the available options to be used with this job template. Use the drop-down menu list to filter by credential type if the list is extensive.

For more information please refer to: <https://docs.ansible.com/automation-controller/latest/html/userguide/job_templates.html>