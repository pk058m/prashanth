# Ansible Automation Platform Technical Roadmap 

This is a .pdf presentation of the technology roadmap for Ansible Automation Platform 2.x.  Gives a good high level overview of the platform with additional technology examples.

![technology_roadmap](/AAP/images/AAP_Tech_Roadmap.pdf)

