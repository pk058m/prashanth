

# Organization

An Organization is a logical collection of Users, Teams, Projects, and Inventories, and is the highest level in the automation controller object hierarchy.


![organization](/AAP/images/TowerHierarchy.png)

An organization has several attributes that may be configured:

* Enter the Name for your organization (required).

* Enter a Description for the organization.

* The Max Hosts is only editable by a superuser to set an upper limit on the number of license hosts that an organization can have. Setting this value to 0 signifies no limit. If you try to add a host to an organization that has reached or exceeded its cap on hosts, an error message displays.

* Enter Instance Groups on which to run this organization.

* Enter the name of the execution environment or search for an existing Default Execution Environment on which to run this organization. See Upgrading to Execution Environments in the Ansible Automation Platform Upgrade and Migration Guide for more information.

* If used, enter the Galaxy Credentials or search from a list of existing ones.

Click Save to finish creating the organization.

For more information please refer to: <https://docs.ansible.com/automation-controller/latest/html/userguide/organizations.html>
