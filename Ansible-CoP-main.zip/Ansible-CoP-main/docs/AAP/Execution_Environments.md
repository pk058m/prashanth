# Automation Execution Environment

An **automation execution environment** is a container image that contains Ansible Core, Ansible Content Collections, and any Python libraries, executables, or other dependencies needed to run your playbook.

![enviroment](/AAP/images/execution_env.jpg)

When you run a playbook with ansible-navigator, you can select an automation execution environment for it to use to run that playbook. When your code is working, you can provide the playbook and the automation execution environment to automation controller (formerly called Red Hat Ansible Tower) and know that automation controller has everything it needs to correctly run your playbook.

The default environment used in Ansible Automation Platform provides Ansible Core and many Red Hat Ansible Certified Content Collections to give you a user experience similar to Ansible 2.9.

# Why use Execution Environments?

Automation execution environments help to ensure that automation runs consistently across multiple platforms and make it possible to incorporate system-level dependencies and collection-based content.

Execution environments give Ansible Automation Platform administrators the ability to provide and manage the right automation environments that meet the needs of different teams, such as networking and cloud teams.

They also enable automation teams to define, build, and update their automation environments themselves.

Execution environments provide a common language to communicate automation dependency between automation developers, architects, and platform administrators.

By providing a standard way to build and distribute the environment automation runs in, automation can also be scaled and shared between teams.

Because they’re defined and standardized, execution environments provide automation developers with a consistent Ansible Automation Platform environment that’s the same as production. And an execution environment can be graduated to run in production.

Another advantage of automation execution environments is that you can use them to run earlier versions of Ansible as well. Red Hat also supports an automation execution environment that provides Ansible 2.9 for compatibility with earlier versions.


*Alternatively, you can use a new tool provided with Ansible Automation Platform called ansible-builder to create your own custom execution environments.*

Red Hat Ansible Automation Platform 2.0 provides three prebuilt automation execution environments:

![table](/AAP/images/execution_table.jpg)

* The minimal automation execution environment only includes the ansible.builtin Ansible Content Collection. You usually reserve it as a starting point to build custom automation execution environments.

* The supported automation execution environment includes some of the collections that Red Hat supports. Automation content navigator and automation controller use it by default. Use this automation execution environment with your new playbooks.

* The compatibility automation execution environment is based on Ansible 2.9, which was released before modules were unbundled from the core Ansible package into collections. This is useful when you want to run playbooks written for Ansible 2.9 (or Red Hat Ansible Automation Platform 1.2) that you have yet not migrated to Red Hat Ansible Automation Platform 2.

Use the automation content navigator to list and inspect the automation execution environments available on the system. To do so, run the ansible-navigator images command:

**[user@demo ~]$ ansible-navigator images**

Red Hat hosts those three automation execution environments in its container registry at **registry.redhat.io**, under the ansible-automation-platform-20-early-access namespace:

* registry.redhat.io/ansible-automation-platform-20-early-access/ee-minimal-rhel8:2.0

* registry.redhat.io/ansible-automation-platform-20-early-access/ee-supported-rhel8:2.0

* registry.redhat.io/ansible-automation-platform-20-early-access/ee-29-rhel8:2.0

You can browse the registry catalog at:  <https://catalog.redhat.com/software/containers/search?build_categories_list=Automation%20Execution%20Environment>.

# Instance Groups 
Logically arrange execution capacity and provide control on where an automation job runs. Instance groups are then assigned with automation controller objects, such as Inventories, Organizations and Job Templates.

Automation mesh worker nodes are associated with instance groups enabling you to allocate the desired execution capacity and location for your platform.