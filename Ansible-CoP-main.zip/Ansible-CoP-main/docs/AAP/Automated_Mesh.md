# Automated Mesh

**Automation mesh** is an overlay network intended to ease the distribution of work across a large and dispersed collection of workers through nodes that establish peer-to-peer connections with each other using existing networks. Automation mesh makes use of unique node types to create both the **control and execution plane.**


Red Hat Ansible Automation Platform 2 **replaces Ansible Tower and isolated nodes with automation controller and automation mesh.** Automation controller provides the control plane for automation through its UI, Restful API, RBAC, workflows and CI/CD integration, while Automation Mesh can be used for setting up, discovering, changing or modifying the nodes that form the control and execution layers.

Automation Mesh introduces:

* Dynamic cluster capacity that scales independently, allowing you to create, register, group, ungroup and deregister nodes with minimal downtime.
* Control and execution plane separation that enables you to scale playbook execution capacity independently from control plane capacity.
* Deployment choices that are resilient to latency, reconfigurable without outage, and that dynamically re-reroute to choose a different path when outages may exist. mesh routing changes.
* Connectivity that includes bi-directional, multi-hopped mesh communication possibilities which are Federal Information Processing Standards (FIPS) compliant.

# Control Plane

The control plane consists of hybrid and control nodes. Instances in the control plane run persistent automation controller services such as the the web server and task dispatcher, in addition to project updates, and management jobs.

* Hybrid nodes - this is the default node type for control plane nodes, responsible for automation controller runtime functions like project updates, management jobs and ansible-runner task operations. 
Hybrid nodes are also used for automation execution.
* Control nodes - control nodes run project and inventory updates and system jobs, but not regular jobs. Execution capabilities are disabled on these nodes.

# Execution plane

The execution plane consists of execution nodes that execute automation on behalf of the control plane and have no control functions. Hop nodes serve to communicate. Nodes in the execution plane only run user-space jobs, and may be geographically separated, with high latency, from the control plane.

* Execution nodes - Execution nodes run jobs under ansible-runner *(Ansible Runner is a tool and python library that helps when interfacing with Ansible directly or as part of another system whether that be through a container image interface, as a standalone tool, or as a Python module that can be imported)* with podman isolation. This node type is similar to isolated nodes.
* Hop nodes - similar to a jump host, hop nodes will route traffic to other execution nodes. Hop nodes cannot execute automation.

# Defining Automation Mesh Node Types

You can a define node type either by its default value assigned by the inventory group or by using the node_type host variable. Specify the node_type either as part of the inventory group or within the inventory vars group. 

 Nodes in [execution_nodes] default execution node_type. Hybrid node types can be overridden to be control type via node_type=control. Execution node type can be overridden to be hope node type via node_type=hop.

 ![automesh](/AAP/images/control.jpg)

You use the Ansible Automation Platform installation program to set up automation mesh or to upgrade to automation mesh. To provide Ansible Automation Platform with details about the nodes, groups, and peer relationships in your mesh network, you define them in an the inventory file in the installer bundle.


For configuration please refer to:  https://access.redhat.com/documentation/en-us/red_hat_ansible_automation_platform/2.2/html/red_hat_ansible_automation_platform_automation_mesh_guide/setting-up