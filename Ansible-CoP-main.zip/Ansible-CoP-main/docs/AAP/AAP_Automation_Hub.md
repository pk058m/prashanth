# Automation Hub

**Automation Hub** is the central place for the certified collections. It functions as the main source of trusted, tested and supported content.


![autohub](/AAP/images/automation_hub.jpg)

Access to Ansible Automation Platform: <https://console.redhat.com/ansible/ansible-dashboard>

**Private Automation Hub** provides automation developers the ability to collaborate and publish their own automation content and streamline delivery of Ansible code within their organization. Private automation hub in Ansible Automation Platform 2.1 primarily delivers support for automation execution environments. *Execution environments are a standardized way to define, build and distribute the environments that the automation runs in.*  In a nutshell, automation execution environments are container images that allow for easier administration of Ansible by the platform administrator.  Enterprises can use private automation hub to manage and control the lifecycle of their Ansible content. They can host Ansible Content Collections and automation execution environments on their private automation hub and provide controlled access to their users.

Different user groups can be content creators, operators, or domain experts, who each need a different level of access to the content. For example, the content creators group needs permission to write and modify the automation code, whereas the operator group needs read-only access to run an automation job. Private automation hub provides a simple but efficient way of managing user access to the content. User access is based on managing permissions to system objects. The system objects are users, groups, namespaces, and repositories.  To manage content and access to content in private automation hub, you can create groups and assign object permissions to those groups. Then you can assign users to these groups, so that each user in a group has the permissions assigned to that group.  This makes it easier to manage permissions for users. Instead of assigning a set of permissions to each user when you create them, you can simply assign that user to a group that grants those permissions.

![private_auto](/AAP/images/private_auto_hub.jpg)

For configuration please refer to: <https://access.redhat.com/documentation/en-us/reference_architectures/2021/html/deploying_ansible_automation_platform_2.1/install_automation_hub>

For managing user access please refer to: <https://access.redhat.com/documentation/en-us/red_hat_ansible_automation_platform/2.1/html/managing_user_access_in_private_automation_hub/index>

# HA Configuration

A high availability (HA) configuration increases reliability and scalablility for automation hub deployments. A deployments of automation hub have multiple nodes that concurrently run the same service with a load balancer distributing workload (an "active-active" configuration). This configuration eliminates single points of failure to minimize service downtime and allows you to easily add or remove nodes to meet workload demands.

For configuration for a High Availability Private Automation Hub please refer to:
<https://access.redhat.com/documentation/en-us/red_hat_ansible_automation_platform/2.2/html/deploying_a_high_availability_automation_hub/index>
