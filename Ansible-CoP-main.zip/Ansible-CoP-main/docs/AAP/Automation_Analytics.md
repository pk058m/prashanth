# Insights for Ansible Automation Platform
Insights for Ansible Automation Platform allows you to keep track of warnings of security vulnerabilities, the security risk levels for your automation controllers, private automation hubs, and other members of your automation infrastructure; the changes that each system has undergone over time, or how far it has moved away from your baselines. Insights for Ansible Automation Platform can even guide you through the process of resolving existing issues on your platform or alert you to proactively eliminate problems before they occur.

The tools for Insights for Ansible Automation Platform are:

* Advisor - Reports on issues with systems and produces remediation playbooks

* Drift - Reports on differences between systems

* Policies - Alerts you to specific changes to system facts

* Notifications - Provides information on automation infrastructure status

* Generating Remediation Playbooks with Advisor
Advisor reports on issues with your systems that Insights for Ansible Automation Platform has identified, and can instantly produce Ansible Playbooks to remediate many of them. You can download these playbooks and run them with your automation controller or with ansible-navigator.

To use Advisor, from the Red Hat Hybrid Cloud Console, access the overview dashboard, and navigate to Advisor → Recommendations.

# Which data is collected by automation analytics?
Automation analytics is built to only collect the minimum amount of data needed.

Data collected from your automation controller (formerly Tower) includes:

* Counts of automation resources (templates, inventories, projects, credentials, etc)
* Topology and status of the automation controller environment and hosts
* Job execution details (start time, finish time, success), individual task success, and modules used
* **No credential secrets, personal data, automation variables, or task output are gathered.**

# How can I view and control the data that is collected by automation analytics?
No data is sent to Red Hat unless an Ansible Automation Platform administrator explicitly initiates the data collection, either during or following a deployment of Ansible Automation Platform.

Administrators can perform a sample collection and inspect the data by running awx-manage gather_analytics and examining the created file.

# Can I limit what data is sent to automation analytics?
No, data collection is not a customizable setting.

# What is the impact of not activating data collection for automation analytics?
Without automation analytics, you will not have visibility into the performance of your automation. Besides the ability to track and measure time and cost-savings, you will not be able to gather data for reporting on the health of your automation and tasks running on your hosts.

# Is the type of data collected static or dynamic?
The specification for what data is collected is defined within the automation controller (formerly Tower) and may change in future Ansible Automation Platform updates.

# How is my analytics data transmitted and stored?
Data is encrypted throughout the process, from collection to transmission, to storage across Red Hat infrastructure.

# How long will Red Hat retain collected data?
By default, the service collects and uploads the data four times a day. Hence, the collected data will normally be kept for up to 24 hours for processing into analytics data. Data uploaded by previous runs will be discarded when the same client uploads new data as part of the daily run. As we are building the product to show performance with historical automation data, automation data is currently stored for up to a year.


# What are your security protocols for Red Hat hosted services?
Ansible Automation Platform hosted services, which includes automation analytics, follows these extensive Red Hat Insights data and application security protocols.

# Can I access automation analytics as on-premise features so that I don’t share system data outside of my network?
Automation analytics is an online service provided within Ansible Automation Platform. No on-premise version of the service is planned at this time.