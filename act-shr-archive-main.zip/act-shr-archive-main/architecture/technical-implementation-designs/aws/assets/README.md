# Assets

Back to [Project](../../../../README.md) | [Architecture](../../../README.md) | [TIDs](../../README.md) | [AWS](../README.md)

This folder was created to store images, external documents, or other assets referenced within our markdown. Assets should have a meaningful name using all lower case with hyphens (e.g. release-mgmt-cycle.jpg).
