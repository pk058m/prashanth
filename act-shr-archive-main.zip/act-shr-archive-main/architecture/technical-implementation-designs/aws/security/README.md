# Security - AWS

Back to [Project](../../../../README.md) | [Architecture](../../../README.md) | [TIDs](../../README.md) | [AWS](../README.md)

---

This section of the architecture repo contains AWS IAM Security specific designs.

- [IAM Identities](iam-identities.md)
