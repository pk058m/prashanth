# Accounts - AWS

Back to [Project](../../../../README.md) | [Architecture](../../../README.md) | [TIDs](../../README.md) | [AWS](../README.md)

This section of the architecture repo contains AWS Account specific designs. The product's ecosystem will consist of the following Accounts:

- [Account Name](some-account.md)
