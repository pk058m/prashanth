# Commercial Off-the-Shelf Software (COTS) - AWS

Back to [Project](../../../../README.md) | [Architecture](../../../README.md) | [TIDs](../../README.md) | [AWS](../README.md)

---

This section of the architecture repo contains AWS COT specific designs.

- [COTS Name](some-cots.md)
