# Resource Naming Standards - AWS

Back to [Project](../../../README.md) | [Architecture](../../README.md) | [TIDs](../README.md) | [AWS](README.md)

---

See the [Reference Architecture Resource Naming Standards](https://github.com/mygainwell/ets-architecture/blob/main/technical-implementation-designs/aws/resource-naming-standards.md)
