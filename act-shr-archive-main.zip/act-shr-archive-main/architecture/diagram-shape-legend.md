# Diagram-as-Code Shape Legend

Back to [Project](../README.md) | [Architecture](README.md)

---

This document defines the common diagram-as-code shapes to be used to represent different components of the architecture. These guidelines should be used for all diagrams within the  documentation repositories.

---

## Resources

- [Reference Architecture Repo](https://github.com/mygainwell/ets-architecture/blob/main/diagram-shape-legend.md)
