# Project Dictionary

Back to [Project](../README.md) | [Architecture](README.md)

---

This document shall serve as a dictionary that defines common terms used throughout the project's documentation, conversations among stakeholders, business owners, architects, developers, and other parties involved in the production of this product.

---

- [Reference Architecture Repo](https://github.com/mygainwell/ets-architecture/blob/main/dictionary.md)

## Some Term

TODO: Some description

## Some Term

TODO: Some description