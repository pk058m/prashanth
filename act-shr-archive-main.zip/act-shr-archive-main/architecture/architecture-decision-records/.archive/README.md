# Archive Directory

This directory is for storing deprecated documents that are no longer applicable as outlined in the [architecture documentation](https://github.com/mygainwell/ets-architecture/blob/main/architecture-decision-records/technical-docs.md) decision record.
