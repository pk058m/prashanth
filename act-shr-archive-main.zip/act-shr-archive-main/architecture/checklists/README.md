# Checklists

Back to [Project](../README.md)

---

This section of the repo contains checklists used for evaluating various aspects of development, deployment, and operational readiness.

- [Reference Architecture Checklists](https://github.com/mygainwell/ets-architecture/tree/main/checklists/README.md)

## Resources

- [ETS Standards Compliance](ets-standards-compliance/README.md)
