# Archive Directory

This directory is for storing deprecated documents that are no longer applicable as outlined in the [architecture documentation](../adr/technical-docs.md) decision record.