﻿SET IDENTITY_INSERT [dbo].[AWBuildVersion] ON 

INSERT [dbo].[AWBuildVersion] ([SystemInformationID], [Database Version], [VersionDate], [ModifiedDate]) VALUES (1, N'13.0.1601.5', CAST(N'2016-04-29T23:23:58.000' AS DateTime), CAST(N'2017-10-19T00:00:00.000' AS DateTime))
SET IDENTITY_INSERT [dbo].[AWBuildVersion] OFF
