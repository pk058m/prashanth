# Batch Workload Components

Back to [Project](../../README.md) | [Components](../README.md)

---

Use this section of the repository to organize batch workload components that make up the application domain. Feel free to reorganize the folder structure to whatever makes sense for the project.

## Project Level Components

- [Batch 1](some-batch.md)
