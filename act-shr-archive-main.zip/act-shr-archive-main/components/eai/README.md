# Enterprise Application Integration - EAI Components

Back to [Project](../../README.md) | [Components](../README.md)

---

Use this section of the repository to organize EAI components that make up the application domain. Feel free to reorganize the folder structure to whatever makes sense for the project.

## Project Level Components

- [EAI Component 1](some-eai.md)
