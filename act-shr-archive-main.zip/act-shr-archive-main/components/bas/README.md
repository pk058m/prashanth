# Business Application Services (BAS) Workload Components

Back to [Project](../../README.md) | [Components](../README.md)

---

Use this section of the repository to organize bas workload components that make up the application domain. Feel free to reorganize the folder structure to whatever makes sense for the project.

## Project Level Components

- [Service 1](some-service.md)