# Report Components

Back to [Project](../../README.md) | [Components](../README.md)

---

Use this section of the repository to organize report components that make up the application domain. Feel free to reorganize the folder structure to whatever makes sense for the project.

## Project Level Components

- [Report Component 1](some-report.md)
