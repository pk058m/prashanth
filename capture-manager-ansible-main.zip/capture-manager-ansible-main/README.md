# Capture Manager Deployment

## Pre-requisites

---

- Drive share configured (FSX or similar)
  - Hostname and share name is required
- Baseline database deployed
  - DB name, instance name, host and port required
  - Service account granted read/write access to DB
- AD Domain Service account
  - Domain, username, and password required
- Hostname of server that will be running Capture Manager

## Configuration

---

### Main YAML Config

`capman_deploy.yml` is the primary configuration file which sets additional facts and conditional statements to ensure hosts have the correct roles and configurations applied.

## Variables to be reviewed

---

### Service Account Variables

| Variable                 | Default Value             | Description                                                            |
| ------------------------ | ------------------------- | ---------------------------------------------------------------------- |
| domain_name              | "{{ capm_svc_domain }}"   | Domain name for service account user e.g. `buildathon.stg`. Set in AAP |
| service_account_username | "{{ capm_svc_username }}" | Username for service account e.g. `SVCTXDevUser`. Set in AAP           |
| service_account_password | "{{ capm_svc_password }}" | Password for service account. Set in AAP                               |

### Database Variables

| Variable                         | Default Value          | Description                                                                                                                                                                          |
| -------------------------------- | ---------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| capm_db_host                     | "dbd01.buildathon.stg" | Hostname for database                                                                                                                                                                |
| capm_db_instance                 | "TXDEVENVPRMGR"        | Name of DB Instance                                                                                                                                                                  |
| capm_db_port                     | "50008"                | Port number DB is listening on                                                                                                                                                       |
| capm_db_database                 | "Tracker"              | Name of database                                                                                                                                                                     |
| capm_db_database_file_net_commit | "HealthPAS_Common"     | Name of filenet database                                                                                                                                                             |
| capm_db_name_toreplace           | "10.134.10.122"        | Used by sql script as `WHERE` condition. This should be the host you are looking to _REPLACE_. Moving forward, this should be `SNAME_PLACEHOLDER` in the baseline DB used for import |

### Fileshare Variables

| Variable            | Default Value          | Description                                                                                                   |
| ------------------- | ---------------------- | ------------------------------------------------------------------------------------------------------------- |
| capm_shared_fs_base | "\\{{ ansible_host }}" | This needs to be the shared filed system path e.g. `amznfsxbzeybsmd.hcls-lev.com\`                            |
| capm_shared_fs_name | "qshare"               | This needs to be the name of the shared file system e.g. `share` as in amznfsxbzeybsmdhcls-lev.com\\`share`\\ |

### Filenet Variables

| Variable                | Default Value                                                             | Description                 |
| ----------------------- | ------------------------------------------------------------------------- | --------------------------- |
| mms_commit_install_path | "C:\\Program Files (x86)\\Molina Healthcare Inc\\MMSFileNetCommitService" | Install path for mms commit |
| filenettype             | "null"                                                                    | TBD                         |
| filenet_is_library      | "TXDEVENVPRMGR"                                                           | TBD                         |
| filenet_uid             | "50008"                                                                   | TBD                         |
| filenet_pw              | "Tracker"                                                                 | Password for FileNet        |
| filenet_p8_uri          | "10.134.10.122"                                                           | URI for filenet             |
| filenet_p8_principal    | "null"                                                                    | Principal                   |

### CMS Workflow Variables

| Variable                       | Default Value                                                                | Description |
| ------------------------------ | ---------------------------------------------------------------------------- | ----------- |
| cms_commit_install_path        | "C:\\Program Files (x86)\\Molina Healthcare Inc\\CM Workflow Server Service" | N/A         |
| cms_wfs_port                   | "8080"                                                                       | N/A         |
| cm_wfs_man_commit_install_path | "C:\\Program Files (x86)\\Molina Healthcare Inc\\CM WFS ManagerService"      | N/A         |

## Full list of variables

Defined via [group_vars](group_vars/all) .

## SQL script

SQL script template located [here](roles/capman-web/templates/sql_update_script.sql.j2)

### EC2 Tags

Not used.

## Post-configuration

---

.Net Users and Roles will need to be added before you can successfully login to the Capture Manager Admin interface. The simple way to do this is to launch IIS as the Service Account user, which can be accomplished by right-clicking IIS while holding shift, which should provide an option to "Open/Run Application as".
