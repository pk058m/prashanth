# Vagrant Testing

:warning: This is still being developed and is intended to provide a basic Windows VM for quick testing of playbooks :warning:

## Info

Tested on macOS 12.3.1
Mac users may need to run the following in order for Ansible to run: `export OBJC_DISABLE_INITIALIZE_FORK_SAFETY=YES`
