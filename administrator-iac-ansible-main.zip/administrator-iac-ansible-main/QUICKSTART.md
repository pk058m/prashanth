# Claims Administrator Ansible Deployment Quick Start Guide


### [See the automation documentation](/README.md)

## 1. Environment requirements.
In order for Ansible to be aware of which Claims Administrator software packages to deploy into an environment, it needs to be able to categorize a virtual machine into a role. Administrator has seven roles for installation which are the following: ui_app, manager_hipaa, worker_hipaa, worker,manager, connect_api, sql_server
To make Ansible aware of the role, each virtual machine in the cloud environment must be tagged with tag name of host_type and for the value of the tag use one of the above values. </br></br>
__It is important important__ to plan the environment by requisitioning the appropriate number of virtual machines for deployment. The smallest possible footprint for Administrator is seven virtual machine in the following roles:</br>
    1. UI application server (ui_app)</br>
    2. Execution Unit (worker)</br>
    3. Distribution Hub (manager)</br>
    4. Execution Unit Hipaa (worker_hipaa)</br>
    5. Distribution Hub (manager_hipaa) </br>
    6. Connect Api, aka Connect BizTalk (connect_api)<br>
    7. SQL Server(s) (sql_server)
    </br></br>
While creating the tags in the cloud management UI the following additional tags need to be created: </br>
    1. DNSHostName - (in AMS/AWS this is the Route53 hostname)<br>
    2. DNSSuffix - (in AMS/AWS this is the Route53 domain for the client) 

>__NOTE:__ Tag names and tag values are case sensitive, not having the correct case or spelling will result in a failed deployment. It is also </br>important to have DNS properly resolving (in AMS\AWS Route53 Domain must be configured with all the VM records in it)
</br>

## 2. Ansible Template and Playbook variable requirements.
In order for Claims Administrator to deploy successfully a number of variables need to be passed in during template or playbook execution. See the list below: </br>
- __artif_base_url:__ "https://gwproductengineering.jfrog.io/artifactory/mms-cms-cef-generic-prod" --> URI to the software repository
- __hpaPackageName:__ "mms.cms.cef.claims_administrator.23.4.0.0" --> Claims Administrator Installation package by Release number
- __soft_version:__ "5.0.16.04" --> Claims Administrator product version. __Note:__ Release number and product version are paired
- __message_store_database:__ "messagestore" --> Product's messagestore database name (default value provided in example)
- __message_store_database_hipaa:__ "messagestore" --> Product's messagestore for Hipaa\X12 transaction database name (default value provided in example)
- __message_store_database_server:__ "AdminSQL2019.dev.mapshc.com\InstanceName" --> SQL server FQDN or IP address and instance
- __message_store_database_server_hipaa:__ "AdminSQL2019.dev.mapshc.com\InstanceName" --> SQL server FQDN or IP address and instance
- __plan_event_database:__ "planevent" --> Product's PlanEvent database name (default value provided in example)
- __plan_event_database_server:__ "AdminSQL2019.dev.mapshc.com\InstanceName" --> SQL server FQDN or IP address and instance
- __security_database_server:__ "AdminSQL2019.dev.mapshc.com\InstanceName" --> SQL server FQDN or IP address and instance
- __security_database:__ "QCSIDB" --> Product's QCSIDB database name (default value provided in example)

## 3. Executing Template and or Playbook.
The execution of a Template or Playbook assumes that the above requirements have been configured and validated. The deployment automation also assumes that all virtual machines are deployed as one execution, for individual deployment is additional advanced variable usage is needed.</br>
When deploying onto a greenfield set of virtual machines. The deployment template that is configured to use the admin_deploy.yml playbook is all that is needed.</br>

In case the execution of deployment template\playbook failure an uninstall execution must precede before the deployment template is executed.
To execute the un-installation template, it must be configured to used the admin_uninstall.yaml playbook and the following variable must be present: </br>

- __artif_base_url:__ "https://gwproductengineering.jfrog.io/artifactory/mms-cms-cef-generic-prod" --> URI to the software repository
- __hpaPackageName:__ "mms.cms.cef.claims_administrator.23.4.0.0" --> Claims Administrator Installation package by Release number
- __soft_version:__ "5.0.16.04" --> Claims Administrator product version. __Note:__ Release number and product version are paired
</br></br>



When deploying into\upgrading an existing environment, the uninstall template that is configured to use the admin_uninstall.yaml playbook needs to be executed first, followed by the deploy template and or playbook.
During upgrade, SQL server databases can be upgraded using the same automation. Each SQL server that is servicing the Claims Administrator product must have the following tags:</br>
1. host_type = sql_server
2. database_inventory_list = PlanData,QCSIDB,PlanIntegration,PlanEvent,MessageStore,PlanDocument<br>


>__NOTE:__ the tag database_inventory_list is unique for each SQL server, depending on which Claims Administrator databases are hosted on it. The database list must be comma separated list.
</br></br>

To execute SQL server upgrade template that has been configured to used the admin_sql_ugrade.yml playbook the following variables must be present: </br>
- __artif_base_url:__ "https://gwproductengineering.jfrog.io/artifactory/mms-cms-cef-generic-prod"  --> URI to the software repository
- __hpaPackageName:__ "mms.cms.cef.claims_administrator.23.4.0.0" --> Claims Administrator Installation package by Release number
- __soft_version:__ "5.0.16.04" --> Claims Administrator product version. __Note:__ Release number and product version are paired
- __hpaSqlPackageName:__ "mms.cms.cef.claims_administrator_db_upgrade_scripts.23.0.4.0" --> Claims Administrator database upgrade package by Release number


