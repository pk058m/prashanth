# CI/CD Checklist

Date:  07/22/2022</br>
Application:  Claims Administrator </br>
ETS reviewer: Dennis Lackey, Jeffery Carpin, Brent Allen, Kenneth Vachon, Shashank Kharel, Dawn Briceno,  Wael Daou, Jeno Mozes</br>
ASO reviewer:  
Product owner reviewer:  
Product engineer reviewer:  
Product Solution Architect reviewer: Jeno Mozes </br>
Final signoff Delivery: Tim/Ken  
Final signoff Product: Ramesh/Jeff  
commit hash for version being certified: 52bcad4eb470147065205461f7d1fe1a740c73af
______________________________________________  

## Assumptions

Load Balancers, Active Directory, DNS, VPC, Firewall etc are in place for this certification  

1. Infrastructure as Code  
    - Is underlying infrastructure provisioning automated?  
    - Are the EC2 tags applied correctly?  

2. SQL database automation
    - Is database provisioning for this application automated?  
    - Is seed database created for the database, if applicable?  
  
______________________________________________  

1. Agile adoption
    - [X] Is the team using Pull Requests for reviews?
    - [X] Is the team tagging PRs with the associated ADO User Story (AB#)
    - [X] Are user stories being closed when branches are merged to main?

2. Source Code
    - [X] Is code in GitHub?
    - [X] Does the repo follow ETS standards for naming and structure?
    - [X] Is team following trunk based development for day to day development activities?
    - [X] Are all development activities happening in GitHub?
       - If not, when will it happen (what code release)?
    - [X] Are developers trained to use GitHub?

3. CI
    - [X] Is your pipeline written as code in YAML in Azure DevOps or GitHub Actions?
    - [X] Is Veracode integration enabled in pipeline?
        - security signoff obtained
    - [X] Is SonarQube integration enabled in pipeline?
        - Product solution architect signoff obtained
    - [N/A] Code coverage (desired state is 90% for testing)
        - What is the current code coverage %? Not Applicable - Creating brownfield unit tests on 24 million lines of code is an in-surmountable effort. Administrator has over 6000 integration tests automated and 32,000 manual, that are part of each product release cycle. These tests do not produce code coverage reports. 
        Moving forward all new projects in Claims Administrator are created with Unit Tests.
        - Product solution architect signoff obtained Not Applicable

4. Artifact Management
    - [X] Is the repository name consistent with GitHub repository
    - [X] Is the product artifact stored in JFrog Artifactory?
    - *common tools and libs*
    - If using containers, is the image stored in JFrog Container Registry? Not Applicable

5. CD
    - [X] Using ansible for CD?
        - [X] Is playbook variablized to scale to deploy to multiple environments?
        - [X] Are all the tasks created as roles?
        - [X] Is playbook dynamically querying EC2 tags to identify machines where install needs to happen?

6. QA (need feedback from Jeff/Oscar/Himanshu)
    - a
    - b

7. Demo complete
    - [X] install
    - [X] uninstall*
    - [X] re-install

8. Document technical debts here

______________________________________________  

## Future Enhancements

1. Monitoring
    - Are the services monitored?

2. ServiceNow
    - catalog
    - master orchestrator
    - queues
    - ORR
    - Auditing
    - Change Request