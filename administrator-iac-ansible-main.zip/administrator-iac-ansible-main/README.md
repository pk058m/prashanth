# administrator-iac-ansible

[![Ansible Lint](https://github.com/mygainwell/administrator-iac-ansible/actions/workflows/ansible-lint.yml/badge.svg?branch=main)](https://github.com/mygainwell/administrator-iac-ansible/actions/workflows/ansible-lint.yml)

#### [See the Quick Start guide](/QUICKSTART.md)
#### [Delivery Checklist](/DELIVERYCHECKLIST.md)

Ansible templates to deploy, uninstall and upgrade SQL databases for the following Claims Administrator applications:

| App         | Description |
| ----------- | ----------- |
| HPA		  | Administrator Web based UI application including Business objects  |
| HPA QFramework      | QFramework is a base software that is included on all Administrator hosts\machines.<br/>Based on host_type tag the QFramwork installer will install additional features <br/> Execution Unit, Distribution Hub |
| HPA Help        | Administrator HTML Help documentation module |
| HPA Rules       | Administrator Rules module to group and or configure default rules |
|HPA_Connect	|	Administrator HIPAA transaction module that supports 4010 and 5010 documents|

## Configuration


### EC2 Tags - Not just EC2, in any cloud environment hosts can be tagged with tags below.
The tags are collected during Ansible inventory refresh operation and the information is used in the Ansible playbooks to properly target hosts to deploy or remove software and or configuration.

| Tag         | Value(s)  | Description |
| ----------- | ----------- | -----------  |
| host_type                   | ui_app </br> manager_hipaa </br> worker_hipaa </br> worker </br> manager </br> connect_api </br> sql_server | Used by all playbooks, it drives decission logic which roles to execute  |
| DNSHostName                   | app01                   | DNS\route 53  host name                         |
| DNSSuffix                     | corp.changeme.com       | DNS\route 53 domain suffix                      |
|database_inventory_list |PlanData,QCSIDB,<br/>PlanIntegration,PlanEvent,<br/>MessageStore,PlanDocument| Comma seperated string to indicate which SQL Database is present on a host with host_type of "sql_server", this tag is used to deliver the database upgrade script for each database type

### Ansible Role to EC2 Tag Mapping

| Role        | EC2 Tag Role Maps to | Description |
| ----------- | ----------- |          ----------- |
| common      |  all                    | Tasks applied to all hosts |
| admin_infra | Not used                | N/A |
| admin_manager| manager, manager_hipaa | Instances to be assigned manager role (aka DH); TAG host_tpe must have a value |
| admin_ui    | ui_app                  | Instances to be assigned ui role; TAG host_tpe must have a value  |
| admin_work  | worker, worker_hipaa    | Instances to be assigned worker role (aka EU) ; TAG host_tpe must have a value|
| connect_api | connect_api             | Instances to be assigned connect_api role for X12 HIPAA import and export ; TAG host_tpe must have a value|
| admin_sql   | sql_server              | Instances to be assigned sql_server role for SQL server database upgrade, this role not to be used with greenfield installation of SQL Server

### Playbook Inentory
| Name             | Description     | Minimum parameters\variables to execute  |
| -----------      | -----------     |          -----------                       |
| admin_deploy.yml | Playbook to install Claims Administrator application on all hosts with tag of host_type (exlcuding host_type of sql_server)| hpaPackageName: "hpa_r24.0.0"-JFrog package name<br/>soft_version: "5.0.24.00"-Administrator product version<br/>message_store_database: "messagestore"<br/>message_store_database_hipaa: "messagestore"<br/>message_store_database_server: "HpasDtlSql16-1.dev.mapshc.com"<br/>message_store_database_server_hipaa: "HpasDtlSql16-1.dev.mapshc.com"<br/>plan_event_database: "planevent"<br/>plan_event_database_server: "HpasDtlSql16-1.dev.mapshc.com"<br/>security_database_server: "HpasDtlSql16-1.dev.mapshc.com"<br/>security_database: "QCSIDB"<br/>connect_biz_talk_server: "adminans0005.dev.mapshc.com"|
|  admin_uninstall.yml | Playbook to uninstall Claims Administrator application on all hosts | hpaPackageName: "hpa_r24.0.0" - Artifactory package name<br/>soft_version: "5.0.24.00" - Claims Administrator product version |
|admin_sql_upgrade| Playbook to upgrade Claims Administrator Databases. Intended for upgrade releases| hpaPackageName: "hpa_r24.0.0"-JFrog package name<br/>soft_version: "5.0.24.00"-Administrator product version<br/>hpaSqlPackageName: "hpa_r24.0.0db_upgrade_scripts"-JFrog package name|
