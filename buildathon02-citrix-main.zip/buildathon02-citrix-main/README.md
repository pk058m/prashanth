##
# **Build-A-Thon 2**
!! Please review the readme.pdf file in the repositiry as the workflow diagrams have not been properly converter in the markdown format !!
##
# **Citrix**

08/09/2022

**[Overview](#_hbe98pu7davm) 3**

**[Ansible Playbooks](#_t4b5kca16un8) 4**

**[Variables](#_qgaejif175r4) 5**

**[Templates](#_lqp4zil14gcr) 9**

**[Workflow](#_auk98aif6odc) 10**

**[Recommendation](#_fbijeaast9dj) 11**

#


# Overview

These playbooks were designed to provision an ec2 instance on AWS, install Citrix, Prims, Flexi and to finally create an AMI from that instance. As of 08/09/2022, The repository buildathon02-citrix has been combined with buildathon02-flexi to accomplish the tasks.

The workflow template (EC2-Citrix-Texas-Master) on Ansible Automation Platform is given below:

![](RackMultipart20220718-1-9x368y_html_410c667023e60f65.png)

#


# Ansible Playbooks

The following playbooks are in the buildathon02-citrix repository:

| Playbook | Purpose |
| --- | --- |
| ec2\_provision\_playbook.yml | Provisions and EC2 Instance on AWS |
| citrix\_playbook.yml | Installs Citrix, Prims, Crowstrike, Cypress Web Controls, Microsoft Edge, Microsoft Office, Nessus, Splunk, Sysmon, and MS Report Builder on the EC2 instance |
| image\_seal\_playbook.yml | Runs the image seal script and shuts down the EC2 instance |
| ec2\_termination\_playbook.yml | Terminates an EC2 instance. When this playbook is run individually, _ **ec2\_instance\_id** _needs to be passed as an extra variable from Ansible Automation Platform. But when it is run in the workflow template, the variables will be passed to the playbook from the other playbooks. |
| ami\_creation\_playbook.yml | Creates an AMI from an EC2. When this playbook is run individually, _ **ec2\_instance\_id** _needs to be passed as an extra variable from Ansible Automation Platform. But when it is run in the workflow template, the variables will be passed to the playbook from the other playbooks. |

# Variables

The playbooks have been designed to use variables in order to make them modular and reusable, so that the entire content of the playbooks do not need to be refactored in a different environment. Another advantage of using variables is that any value can be updated before running the playbooks from Ansible Automation Platform.

| Playbook | Variable files |
| --- | --- |
| ec2\_provision\_playbook.yml |1. vars\_ec2.yml 2. On Ansible Automation Platform, a new Credential Type _Citrix Admin_ was created|
| Variable name | Purpose |
| citrix\_admin\_username (Created on AAP of type Citrix Admin) | Username of the local user to be created on the ec2 instance |
| citrix\_admin\_password (Created on AAP of type Citrix Admin) | Password for the local user |
| region | The region to provision the ec2 in |
| ami\_id | The ami id of a native AWS image to use to provision the ec2 |
| owner | Owner of the instance |
| windows\_instance\_type | Type of ec2 instance |
| ec2\_volume\_type | Volume type to attach to ec2 |
| ec2\_volume\_size | Volume size to attach to ec2 |
| ec2\_volume\_device\_name | The device name of the volume |
| number\_of\_instances | Number of instances to provision |
| key\_name | The key to use for the ec2 instance |
| group\_id | Security groups to attach to the ec2 instance. Multiple security groups can be passed in as a string array argument |
| vpc\_subnet\_id | Subnet ID of the VPC |
| instance\_tags | Tags for the instance |
| instance\_name | Name of the instance |
| state\_tag | Add a state tag |
| environment\_tag | Add an environment tag |
| database\_tag | Add a database tag |
| ui\_tag | Add a user tag |
| workload\_dns | The workload dns to set for the ec2 instance |
| user\_data | It is a Jinja 2 template (user\_data.ps1.j2) that runs a set of commands to apply a certain configuration on the ec2 instance on startup. Details of this file are discussed in the templates section. |

| Playbook | Variable files |
| --- | --- |
| citrix\_playbook.yml | vars\_windows.yml |
| Variable name | Purpose |
| base\_url | Base JFrog URL |
| citrix\_jfrog\_url | URL to Citrix directory on JFrog |
| prims\_jfrog\_url | URL to PRIMS directory on JFrog |
| bitmap\_jfrog\_url | URL to bitmap directory on JFrog |
| ctx\_tools folder | CTX tools directory |
| prims\_install\_folder | PRIMS installation directory |
| prims\_install\_folder\_shell | Also prims installation folder, which should point to the same directory as prims\_install\_folder. The second variable was created to pass the path in a script that required a different syntax. |
| prims\_temp\_download\_folder | Path to a directory to download the require files for the installation temporarily |
| prims\_temp\_download\_folder\_shell | Same path as the prims\_temp\_download\_folder, but in a different syntax |
| registry\_silent\_setting | Location of the script to invoke silent installation of prims |
| usoft\_exe\_file | Prims installer file |
| license\_file | Prims license file |
| verify\_install\_file | Prims installation verification file |
| license\_mgr\_service\_name | Prims license manager service name |
| windows\_temp\_download\_folder | Path to the download folder for Citrix tools |
| microsoft\_edge\_zip\_file | Zip filename for Edge on JFrog |
| microsoft\_edge\_msi\_file | MSI filename for Edge on JFrog |
| splunk\_zip\_file | Zip filename for Splunk on JFrog |
| splunk\_msi\_file | MSI filename for Splunk on JFrog |
| splunk\_username | Splunk username |
| splunk\_password | Splunk password |
| splunk\_deployment\_server | Deployment server for Splunk |
| splunk\_install\_arguments | Parameters to install Splunk |
| nessus\_zip\_file | Zip filename for Nessus on JFrog |
| nessus\_msi\_file | MSI filename for Nessus on JFrog |
| nessus\_groups | Nessus group name to pass an argument to the installer |
| nessus\_server | Nessus server name to pass an argument to the installer |
| nessus\_key | Nessus key to pass an argument to the installer |
| nessus\_install\_arguments | Parameters to install Nessus |
| sysmon\_zip\_file | Zip filename for Sysmon on JFrog |
| sysmon\_exe\_file | Exe filename for Sysmon on JFrog |
| crowdstrike\_zip\_file | Zip filename for Crowdstrike on JFrog |
| crowdstrike\_exe\_file | Exe filename for Crowdstrike on JFrog |
| crowdstrike\_cid | CID for crowdstrike |
| crowdstrike\_grouping\_tags | Grouping tag for crowdstrike |
| crowdstrike\_install\_arguments | Parameters to install crowdstrike |
| crowdstrike\_domain | Domain name for Crowdstrike |
| crowdstrike\_admin\_domain | Admin domain name for Crowdstrike |
| Crowdstrike\_username, crowdstrike\_password | Username for Crowdstrike. A credential type "Citrix Service Account" and a credential "Citrix-Stage-Service-Account" was created on AAP where the playbook is retrieving the username and password from |
| ms\_reportBuilder\_zip\_file | Zip filename for MS Report Builder on JFrog |
| cypress\_web\_controls\_zip\_file | Zip filename for Cypress Web Controls on JFrog |
| cypress\_web\_controls\_msi\_file | MSI filename for Cypress Web Controls on JFrog |
| cypress\_web\_controls\_install\_dir | Cypress Web Controls installation directory |

| Playbook | Variable files |
| --- | --- |
| ami\_creation\_playbook.yml | vars\_ec2.yml |
| Variable name | Purpose |
| ec2\_instance\_id (passed as extra vars from Ansible Automation Platform) | Instance id of the ec2 instance to use to create the AMI. If the playbook is run in the provided workflow, the variable does not need to be provided. Otherwise the variable has to be passed as an extra variable from Ansible Automation Platform. |
| ec2\_ami\_name | Name of the AMI to be created |

| Playbook | Variable files |
| --- | --- |
| ec2\_termination\_playbook.yml | vars\_ec2.yml |
| Variable name | Purpose |
| ec2\_instance\_id (passed as extra vars from Ansible Automation Platform) | Instance id of the ec2 instance to use to create the AMI. If the playbook is run in the provided workflow, the variable does not need to be provided. Otherwise the variable has to be passed as an extra variable from Ansible Automation Platform. |
| region | Region of the EC2 instance |
| ec2\_state | Target state for the EC2 instance |

#


#


# Templates

Templates are very powerful tools in Ansible. Using templates allows the users to easily change a value in a file without hardcoding it. The variables used in the templates have been mentioned in the above section. The following templates are used in the playbooks:

| Template name | Used in Playbook | Purpose |
| --- | --- | --- |
| user\_data.ps1.j2 | ec2\_provision\_playbook.yml | Applies the following configuration on the ec2 instance on startup-- Enables winrm on the ec2 instance for ansible to communicate- Disables Firewall and Windows Defender- Creates a local user and adds the user to the administrator group. Uses the &quot;_citrix\_admin\_username&quot;_ and &quot;_citrix\_admin\_password&quot;_ variables - Sets the workload dns. Uses the variable &quot;_workload\_dns&quot;_|
| install.sss.j2 | citrix\_playbook.yml | Silent installer for prims. Uses the variable _&quot;prims\_install\_folder&quot;_ |
| prims\_silent\_install.reg.j2 | citrix\_playbook.yml | Registers prims silent installer. Uses the variables _&quot;prims\_temp\_download\_folder\_shell&quot;_ and _&quot;prims\_install\_folder\_shell&quot;_ |

#


# Workflow

Following is the workflow of the playbooks in the buildathon02-citrix repository

![](RackMultipart20220718-1-9x368y_html_14844d1447c71126.png)

#


# Recommendation

1. One known error has been identified while running the EC2 Provision Playbook. It will show the following error on AAP. The root cause for this error is, on AWS there is already an EC2 with the same name, which causes a conflict on the Ansible side.

| An exception occurred during task execution. To see the full traceback, use -vvv. The error was: botocore.exceptions.ClientError: An error occurred (UnauthorizedOperation) whencalling the ModifyInstanceAttribute operation: You arenot authorized to perform this operation. |
| --- |

The fix for this issue is to terminate the EC2 that has the same name, and to run the playbook again.

2. The CypressWebControls installer that was provided seems to be problematic. We noticed that it does not get installed when the command is run for the first time. It takes at least two tries to get it installed. The task for the installation is located in (roles/install_windows_apps/tasks/install_cypress_web_controls.yml). As of 08/13/2022, the same command is run twice to install it. One possible reason for this issue might be the installer being 32 bit, where the server is 64 bit. When the command is run manually from cmd, the same behavior is seen. It is recommended to update the 32 bit installer with a 64 bit installer.