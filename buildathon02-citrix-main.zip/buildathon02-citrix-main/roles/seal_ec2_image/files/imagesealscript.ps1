﻿Set-ExecutionPolicy -Force Bypass

# Force .net Runtime Optimization Service

# *********************


Get-ChildItem  C:\Windows\Microsoft.NET\Framework\v4.0.30319 ngen.exe -Recurse | ForEach-Object {
  & $_.FullName update
}

Get-ChildItem  C:\Windows\Microsoft.NET\Framework64\v4.0.30319 ngen.exe -Recurse | ForEach-Object {
  & $_.FullName update
}

schtasks /change /TN "\Microsoft\Windows\.NET Framework\.NET Framework NGEN v4.0.30319" /Disable
schtasks /change /TN "\Microsoft\Windows\.NET Framework\.NET Framework NGEN v4.0.30319 64" /Disable

# *********************

# Stop and disable Windows update service

Stop-Service -name "wuauserv"

Set-Service -name "wuauserv" -StartupType Disabled


# *********************

# Stop and disable Windows Orchestration service

Stop-Service -name "usosvc"

Set-Service -name "usosvc" -StartupType Disabled

# *********************

# Stop and disable Windows Telemetry service

Set-Service -name "DiagTrack" -StartupType Disabled

Set-Service -name "dmwappushservice" -StartupType Disabled

# *********************

# Delete any existing shadow copies

# vssadmin delete shadows /All /Quiet

# *********************

# delete files in c:\Windows\SoftwareDistribution\Download\ /f /s /q

Start-process cmd.exe "/C","del c:\Windows\SoftwareDistribution\Download\*.* /f /s /q " -Verb runas

# *********************

# delete hidden install files /f /s /q /a:h

Start-process cmd.exe "/c","del c:\windows\$NT* /f /s /q /a:h" -Verb runas

# *********************

# delete prefetch files

Start-process cmd.exe "/c","del c:\Windows\Prefetch\*.* /f /s /q" -Verb runas

# *********************

# Run Disk Cleanup to #ove temp files, empty recycle bin
# and #ove other unneeded files
# Note: Makes sure to run c:\windows\system32\cleanmgr /sageset:1 command
# on your initially created parent image and check all the boxes
# of items you want to delete

$cleanloc = "c:\windows\system32\cleanmgr"

$cleanarg = "/sagerun:1"

Start-process -Filepath $cleanloc -argumentlist $cleanarg -Verb runas -wait

# *********************

# Stop uberagent Service

Stop-Service -name "uberagent"

# *********************

# Delete uberagent registry key

Remove-Item -Path "HKLM:\SOFTWARE\vast limits\uberAgent" -Recurse -Force -ErrorAction SilentlyContinue 

# *********************

# Stop SPLUNK Service

Stop-Service -name "splunkforwarder"

# SPLUNK clone-prep-clear-config

$splunkloc =  "C:\Program Files\SplunkUniversalForwarder\bin\splunk.exe"
$splunkarg = "clone-prep-clear-config"

Start-process -Filepath $splunkloc -argumentlist $splunkarg -Verb runas

# *********************

# Stop Trend Micro Agents

# Stop-Service -name "ds_agent"
# Stop-Service -name "ds_monitor"
# Stop-Service -name "ds_notifier"

# *********************

# *********************

# Defragment the VM disk

Set-Service -Name "defragsvc" -StartupType Manual

Start-Service -Name "defragsvc"

$defragloc = "c:\windows\system32\defrag.exe"

$defragarg = "c: /u /v"

Start-process -filepath $defragloc -argumentlist $defragarg -Verb runas -Wait

Stop-Service -name "defragsvc"

Set-Service -Name "defragsvc" -StartupType Disabled

# ********************

# Flush DNS

Clear-DnsClientCache

# ********************

# Clear all event logs

wevtutil el 1>cleaneventlog.txt

$eventlog = Get-Content cleaneventlog.txt

foreach ($event in $eventlog) {
      wevtutil cl $event
}

Remove-Item cleaneventlog.txt

# *********************

# Delete content of Windows\Temp

Remove-Item -Path C:\Windows\TEMP\* -Recurse -Force -ErrorAction SilentlyContinue

# *********************

# Run AWS InitializeInstance script

 & C:\ProgramData\Amazon\EC2-Windows\Launch\Scripts\InitializeInstance.ps1 -Schedule

# shutdown /s /f /t '0'

Exit
